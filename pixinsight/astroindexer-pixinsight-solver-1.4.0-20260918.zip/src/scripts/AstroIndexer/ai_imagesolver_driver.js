// ============================================================================
// ai_imagesolver_driver.js - AstroIndexer headless PixInsight plate-solve driver
// Version: 1.4.0  (2026-09-18)
//
// Drives PixInsight's ImageSolver engine WITHOUT its dialog (USE_SOLVER_LIBRARY)
// to plate-solve a single image as a LAST-RESORT backend for AstroIndexer, used
// only after ASTAP + astrometry.net have both failed.
//
// TWO RUN MODES:
//   * HEADLESS (how AstroIndexer uses it): launched with --startup-script and the
//     env var ASTROINDEXER_PI_SOLVE_PARAMS pointing at a params file. Solves and
//     writes the WCS to the status file. No GUI.
//   * INTERACTIVE (a user clicks Script > AstroIndexer > AI ImageSolver Driver):
//     no params env var is set, so instead of doing nothing it shows an info +
//     status dialog (what it is, requirements check incl. local Gaia DR3, and a
//     link to the AstroIndexer website). v1.1.0.
//
// CONTRACT (file-based IPC with the Python PixInsightSolver):
//   * Reads a params file whose path is in the env var ASTROINDEXER_PI_SOLVE_PARAMS.
//     params (key=value per line): input, output, status, ra_hint, dec_hint, fov_hint
//   * On success: saves the solved image (WCS in the FITS header) to `output` and
//     writes "SOLVED" + the linear WCS to `status`.
//   * On any failure: writes "FAILED: <reason>" to `status` and exits. NEVER blocks
//     on a dialog (so the Python side's timeout/kill is a backstop, not the norm).
//
// ACTIVATION: this script MUST be code-signed in PixInsight (Script > Code Signing)
// before `--startup-script=` will run it headlessly; an UNSIGNED copy makes PI hang
// on a "Required code signature not found" modal (that is why PixInsightSolver gates
// is_available() on a signature and bounds the run with a hard timeout). It also
// needs a local Gaia DR3/XPSD database configured in PixInsight.
//
// Version history:
//   1.1.0 (2026-06-26): Add the interactive info/status dialog (run from the Script
//          menu). Headless solve path unchanged. Re-sign required.
//   1.0.0 (2026-06-15): Initial headless driver.
// ============================================================================

// PixInsight 1.9.4 removed the legacy 'sm' (SpiderMonkey) engine. Declare the v8 engine
// explicitly - the stock ImageSolver.js we #include already declares '#engine v8'. Without
// this, the driver loads under the now-unavailable default engine and aborts before running.
#engine v8

// Required for code signing: PixInsight's generateScriptSignatureFile() derives the
// signed script-id from this directive (every signable stock script declares one).
#feature-id    AstroIndexerAIImageSolver : AstroIndexer > AI ImageSolver Driver

#define USE_SOLVER_LIBRARY  true
// USE_SOLVER_LIBRARY makes ImageSolver.js SKIP its own '#define SETTINGS_MODULE' (it assumes the
// embedding script owns the settings namespace), yet its catalog classes (AstronomicalCatalogs.js)
// reference SETTINGS_MODULE at load -> we MUST define it before the include. Use "ImageSolver" so the
// driver reads the user's existing ImageSolver catalog / local Gaia DR3 configuration.
#define SETTINGS_MODULE  "ImageSolver"
// Installed under <PixInsight>/src/scripts/AstroIndexer/, so ImageSolver is one level up.
// Matches the stock convention (AutoIntegrate, BatchPreprocessing both use this exact path).
#include "../ImageSolver/ImageSolver.js"

#define AI_DRIVER_VERSION   "1.4.0"
#define AI_WEBSITE_URL      "https://astroindexer.com/pixinsight-plate-solver.html"
#define AI_REPO_URL         "https://astroindexer.com/pixinsight/"

function _readParams( path )
{
   var p = { input:"", output:"", status:"", ra_hint:"", dec_hint:"", fov_hint:"",
             log:"", distortion:"", exhaustive:"", intersection:"", cfg:"" };
   var text = File.readTextFile( path );
   var lines = text.split( "\n" );
   for ( var i = 0; i < lines.length; ++i )
   {
      var s = lines[i].trim();
      var eq = s.indexOf( "=" );
      if ( eq > 0 )
         p[ s.substring( 0, eq ).trim() ] = s.substring( eq + 1 ).trim();
   }
   return p;
}

function _writeStatus( path, msg )
{
   try { File.writeTextFile( path, msg + "\n" ); } catch ( e ) {}
}

// ---------------------------------------------------------------------------
// Interactive info/status dialog (run from the Script menu, no params env var).
// ---------------------------------------------------------------------------

function _piVersionString()
{
   try {
      return format( "%d.%d.%d", CoreApplication.versionMajor,
                     CoreApplication.versionMinor, CoreApplication.versionRelease );
   } catch ( e ) { return "unknown"; }
}

function _piVersionOK()
{
   try {
      var M = CoreApplication.versionMajor, m = CoreApplication.versionMinor, r = CoreApplication.versionRelease;
      return (M > 1) || (M == 1 && (m > 9 || (m == 9 && r >= 4)));
   } catch ( e ) { return true; } // don't false-alarm if the version can't be read
}

// Local Gaia DR3 / XPSD database check, using the SAME API the stock ImageSolver uses
// (ImageSolverEngine.js: new Gaia; command="get-info"; isValid; outputDataRelease).
function _gaiaStatus()
{
   try {
      if ( typeof Gaia == 'undefined' )
         return { ok:false, text:"Gaia XPSD process not available in this PixInsight." };
      var xpsd = new Gaia;
      xpsd.command = "get-info";
      xpsd.dataRelease = Gaia.DataRelease_BestAvailable;
      xpsd.executeGlobal();
      if ( xpsd.isValid )
      {
         var dr = "Gaia";
         switch ( xpsd.outputDataRelease )
         {
         case Gaia.DataRelease_3:  dr = "Gaia DR3";  break;
         case Gaia.DataRelease_E3: dr = "Gaia EDR3"; break;
         case Gaia.DataRelease_2:  dr = "Gaia DR2";  break;
         default: break;
         }
         return { ok:true, text:"Local " + dr + " XPSD database configured." };
      }
      return { ok:false, text:"Gaia process found, but no valid local XPSD database is configured." };
   } catch ( e ) {
      return { ok:false, text:"Could not query Gaia (" + e.message + ")." };
   }
}

function _statusLine( ok, label, value )
{
   var color = ok ? "#5fcf80" : "#e0a13a";
   var mark  = ok ? "OK" : "!";
   return "<b><font color='" + color + "'>[" + mark + "]</font></b> " + label + ": " + value;
}

function _showInfoDialog()
{
  try
  {
   var piOK = _piVersionOK();
   var gaia = _gaiaStatus();

   var dlg = new Dialog;
   dlg.windowTitle = "AstroIndexer AI ImageSolver Driver";

   var header = new Label( dlg );
   header.useRichText = true;
   header.text = "<b>AstroIndexer AI ImageSolver Driver</b> &nbsp; v" + AI_DRIVER_VERSION;

   var desc = new Label( dlg );
   desc.useRichText = true;
   desc.wordWrapping = true;
   desc.setScaledMinWidth( 480 );
   desc.text =
      "This is a <i>headless</i> plate-solving driver used by <b>AstroIndexer</b> - you do " +
      "not run it manually. AstroIndexer launches it automatically as a last-resort plate " +
      "solver for processed and final frames that ASTAP and astrometry.net cannot match " +
      "(their altered star profiles defeat quad matching). It drives PixInsight's ImageSolver " +
      "against your local Gaia DR3 catalog and returns the astrometric solution to AstroIndexer.";

   var statusGroup = new GroupBox( dlg );
   statusGroup.title = "Status";
   statusGroup.sizer = new VerticalSizer;
   statusGroup.sizer.margin = 8;
   statusGroup.sizer.spacing = 6;

   var sPI = new Label( dlg );
   sPI.useRichText = true;
   sPI.text = _statusLine( piOK, "PixInsight",
      _piVersionString() + (piOK ? " (1.9.4+ OK)" : " - 1.9.4 or newer required") );

   var sIS = new Label( dlg );
   sIS.useRichText = true;
   // We reached this point, so the #include of ImageSolver resolved -> it is present.
   sIS.text = _statusLine( true, "ImageSolver", "Available." );

   var sGaia = new Label( dlg );
   sGaia.useRichText = true;
   sGaia.wordWrapping = true;
   sGaia.setScaledMinWidth( 480 );
   sGaia.text = _statusLine( gaia.ok, "Local Gaia DR3", gaia.text );

   statusGroup.sizer.add( sPI );
   statusGroup.sizer.add( sIS );
   statusGroup.sizer.add( sGaia );

   if ( !gaia.ok )
   {
      var gaiaHint = new Label( dlg );
      gaiaHint.useRichText = true;
      gaiaHint.wordWrapping = true;
      gaiaHint.setScaledMinWidth( 480 );
      gaiaHint.styleSheet = "color:#9aa4b2;";
      gaiaHint.text =
         "Configure a local Gaia DR3 / XPSD database in PixInsight (the same one ImageSolver " +
         "uses) so the solver can work offline. See PixInsight: Resources &gt; Gaia DR3.";
      statusGroup.sizer.add( gaiaHint );
   }

   var linkLabel = new Label( dlg );
   linkLabel.useRichText = true;
   linkLabel.wordWrapping = true;
   linkLabel.setScaledMinWidth( 480 );
   linkLabel.text =
      "Documentation &amp; install help:<br/>" +
      "<a href='" + AI_WEBSITE_URL + "'>" + AI_WEBSITE_URL + "</a>";

   // Read-only, selectable copy of the URLs (guaranteed copyable even if links are not clickable).
   var urlBox = new Edit( dlg );
   urlBox.text = AI_WEBSITE_URL;
   urlBox.readOnly = true;

   var repoLabel = new Label( dlg );
   repoLabel.useRichText = true;
   repoLabel.text = "Update repository URL (Resources &gt; Updates &gt; Manage Repositories):";
   var repoBox = new Edit( dlg );
   repoBox.text = AI_REPO_URL;
   repoBox.readOnly = true;

   var okBtn = new PushButton( dlg );
   okBtn.text = "OK";
   okBtn.defaultButton = true;
   okBtn.onClick = function() { dlg.ok(); };

   var btnSizer = new HorizontalSizer;
   btnSizer.addStretch();
   btnSizer.add( okBtn );

   dlg.sizer = new VerticalSizer;
   dlg.sizer.margin = 12;
   dlg.sizer.spacing = 10;
   dlg.sizer.add( header );
   dlg.sizer.add( desc );
   dlg.sizer.add( statusGroup );
   dlg.sizer.add( linkLabel );
   dlg.sizer.add( urlBox );
   dlg.sizer.add( repoLabel );
   dlg.sizer.add( repoBox );
   dlg.sizer.addSpacing( 4 );
   dlg.sizer.add( btnSizer );

   dlg.adjustToContents();
   dlg.setScaledMinWidth( 520 );
   dlg.execute();
  }
  catch ( e )
  {
     // Never crash the menu item - fall back to the Process Console with the same info.
     try {
        Console.show();
        Console.writeln( "<end><cbr><br>AstroIndexer AI ImageSolver Driver v" + AI_DRIVER_VERSION );
        Console.writeln( "Headless plate-solver driver used by AstroIndexer (last-resort solver)." );
        Console.writeln( "Documentation: " + AI_WEBSITE_URL );
        Console.writeln( "Update repository URL: " + AI_REPO_URL );
        Console.writeln( "Local Gaia DR3: " + _gaiaStatus().text );
        Console.writeln( "(The info dialog could not be shown: " + e.message + ")" );
     } catch ( e2 ) {}
  }
}

function main()
{
   var paramsPath = "";
   if ( typeof( System ) != "undefined" && typeof( System.getEnvironmentVariable ) == "function" )
      paramsPath = System.getEnvironmentVariable( "ASTROINDEXER_PI_SOLVE_PARAMS" );
   else if ( typeof( environmentVariable ) != "undefined" )
      paramsPath = environmentVariable( "ASTROINDEXER_PI_SOLVE_PARAMS" );

   // No params file -> the user launched this from the Script menu (not AstroIndexer).
   // Show the info/status dialog instead of silently doing nothing. In headless/automation
   // mode there is no display, so never open a GUI - just return.
   if ( !paramsPath || !File.exists( paramsPath ) )
   {
      // jsAutomationMode is defined ONLY under --automation-mode; in an interactive run it is
      // undefined, so guard with typeof (a bare reference throws ReferenceError).
      var headless = (typeof jsAutomationMode != "undefined") && jsAutomationMode;
      if ( !headless )
         _showInfoDialog();
      return;
   }

   var P = _readParams( paramsPath );
   if ( !P.status )
      return;

   try
   {
      if ( !P.input || !File.exists( P.input ) )
      {
         _writeStatus( P.status, "FAILED: input missing" );
         return;
      }

      // Open the target (PI reads FITS + XISF natively - no transcode needed).
      // v1.3.0: ImageSolver writes its diagnostics (star counts, limit-magnitude search,
      // per-iteration residuals, and the reason an initial alignment failed) to the Process
      // Console, which does NOT reach stdout under --automation-mode. Without this the Python
      // side sees only the exception text, which is why GitHub #817 sat unexplained: its RCA
      // asked for the console report and there was no way to obtain one.
      if ( P.log !== "" )
         try { Console.beginLog( P.log ); } catch ( e ) { /* logging is best-effort */ }

      var windows = ImageWindow.open( P.input );
      if ( windows.length == 0 )
      {
         _writeStatus( P.status, "FAILED: could not open input" );
         return;
      }
      var win = windows[0];

      // Configure + run ImageSolver as a library, no dialog. API per ImageSolver 6.4.2
      // (ImageSolverEngine.js): initialize()/solveImage() - lowercase, take the WINDOW.
      var solver = new ImageSolver();
      solver.initialize( win, false /*prioritizeSettings*/ );  // load metadata from the image
      // v1.2.0: distortion correction is LEFT ENABLED (the ImageSolver default).
      //
      // It used to be disabled here so that PixInsight would keep writing standard FITS WCS
      // keywords, because a non-linear solution cannot be stored in FITS. That rationale is
      // dead twice over: PixInsight 1.9.5's ImageSolver writes NO FITS WCS keywords at all
      // and removes any present, and AstroIndexer has never read the output file anyway - it
      // reads the WCS from the status file below.
      //
      // Disabling it actively BROKE wide fields. ImageSolver's initial alignment relies on the
      // distortion phase to converge: a pure homography absorbs the gnomonic projection's own
      // deformation across a small field, but not across several degrees, so the alignment
      // failed with "Failed to perform the initial field alignment" on every APO 94mm frame
      // (1.873 as/px, 3.25 deg) while 0.68 deg frames solved fine (GitHub #817). Binning never
      // helped because binning changes the pixel count, not the field of view.
      //
      // Enabling it does NOT change what AstroIndexer ingests: GetWCSvalues() detects a spline
      // solution and returns its linear approximation (ref_I_G_linear), so the status file still
      // carries a linear TAN - now the best linear fit of a properly solved field instead of the
      // only fit a homography could manage.
      // v1.3.0: the robustness options ImageSolver documents as the remedies for a failed
      // initial alignment, settable per-solve so they can be tested WITHOUT re-signing the
      // driver (any byte change invalidates its CPD signature).
      //   distortion=0|1        solverCfg.distortionCorrection            (default: leave alone)
      //   exhaustive=1          solverCfg.tryExhaustiveInitialAlignment   (ImageSolver default false)
      //   intersection=n|a|w    solverCfg.intersectionMode  never|auto|always (default automatic,
      //                         which selects Always only at an aspect ratio >= 2:1)
      if ( P.distortion !== "" )
         solver.solverCfg.distortionCorrection = (P.distortion == "1");
      if ( P.exhaustive !== "" )
         solver.solverCfg.tryExhaustiveInitialAlignment = (P.exhaustive == "1");
      if ( P.intersection !== "" )
         solver.solverCfg.intersectionMode =
            (P.intersection.charAt( 0 ) == "a") ? 2 :          // IntersectionMode.Always
            (P.intersection.charAt( 0 ) == "n") ? 0 : 1;       // Never : Automatic

      // v1.4.0: generic solverCfg passthrough - "cfg=key:value,key:value". Any ImageSolver
      // option becomes testable WITHOUT another signing cycle, which is the whole cost of
      // iterating on a signed artifact. Star-detection options matter here in particular:
      // hotPixelFilterRadius, minStructureSize, sensitivity, peakResponse, structureLayers.
      // "true"/"false" become Booleans, numeric strings become Numbers, anything else stays
      // a String. An unknown key is reported to the log, never fatal.
      if ( P.cfg !== "" )
      {
         var cfgItems = P.cfg.split( "," );
         for ( var ci = 0; ci < cfgItems.length; ++ci )
         {
            var sep = cfgItems[ci].indexOf( ":" );
            if ( sep < 1 )
               continue;
            var cfgKey = cfgItems[ci].substring( 0, sep ).trim();
            var cfgRaw = cfgItems[ci].substring( sep + 1 ).trim();
            var cfgVal;
            if ( cfgRaw == "true" )
               cfgVal = true;
            else if ( cfgRaw == "false" )
               cfgVal = false;
            else if ( cfgRaw.length > 0 && !isNaN( Number( cfgRaw ) ) )
               cfgVal = Number( cfgRaw );
            else
               cfgVal = cfgRaw;
            try {
               solver.solverCfg[cfgKey] = cfgVal;
               Console.writeln( "* solverCfg." + cfgKey + " = " + cfgVal );
            } catch ( eCfg ) {
               Console.writeln( "** solverCfg." + cfgKey + " could not be set: " + eCfg );
            }
         }
      }

      solver.metadata.width  = win.mainView.image.width;
      solver.metadata.height = win.mainView.image.height;
      // Seed hints when AstroIndexer provides them (faster, more robust solve).
      if ( P.ra_hint !== "" && P.dec_hint !== "" )
      {
         solver.metadata.ra  = parseFloat( P.ra_hint );
         solver.metadata.dec = parseFloat( P.dec_hint );
      }
      if ( P.fov_hint !== "" )
         solver.metadata.resolution = parseFloat( P.fov_hint ) / Math.max( 1, win.mainView.image.width );
      solver.metadata.SaveParameters();
      solver.solverCfg.SaveParameters();

      // solveImage() THROWS on failure (e.g. insufficient stars) - no boolean return; the
      // outer catch turns that into "FAILED: <reason>". On success it updates solver.metadata.
      solver.solveImage( win );

      // PI's FITS writer stores the astrometric solution as XISF properties (dropped on FITS save)
      // and emits NO CRVAL/CD cards, so reading the WCS back from the output FITS is unreliable.
      // Instead read the linear WCS straight from the solution and hand it to the Python side via
      // the status file - deterministic, independent of PI's FITS-keyword behaviour.
      var wcs = solver.metadata.GetWCSvalues();

      // Still save the solved image (a bonus for the user); the status WCS below is the authority.
      try {
         solver.metadata.SaveKeywords( win, false /*beginProcess*/ );
         win.saveAs( P.output, false /*queryOptions*/, false /*allowMessages*/,
                     false /*strict*/, false /*verifyOverwrite*/ );
      } catch ( e ) { /* output FITS is best-effort; Python reads the WCS from the status file */ }
      win.forceClose();

      _writeStatus( P.status,
         "SOLVED" +
         "\ncrval1=" + wcs.crval1 + "\ncrval2=" + wcs.crval2 +
         "\ncd1_1="  + wcs.cd1_1  + "\ncd1_2="  + wcs.cd1_2 +
         "\ncd2_1="  + wcs.cd2_1  + "\ncd2_2="  + wcs.cd2_2 +
         "\ncrpix1=" + wcs.crpix1 + "\ncrpix2=" + wcs.crpix2 );
      try { Console.endLog(); } catch ( e2 ) { /* no-op */ }
   }
   catch ( e )
   {
      // The status file is written FIRST: it is the contract the Python side reads, and a
      // failure to close the log must never cost us the reason for the failure.
      _writeStatus( P.status, "FAILED: " + e.toString() );
      try { Console.endLog(); } catch ( e2 ) { /* no-op */ }
   }
}

main();
