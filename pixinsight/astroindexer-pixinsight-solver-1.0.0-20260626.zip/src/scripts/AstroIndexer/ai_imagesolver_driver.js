// ============================================================================
// ai_imagesolver_driver.js - AstroIndexer headless PixInsight plate-solve driver
// Version: 1.0.0  (2026-06-15)
//
// Drives PixInsight's ImageSolver engine WITHOUT its dialog (USE_SOLVER_LIBRARY)
// to plate-solve a single image as a LAST-RESORT backend for AstroIndexer, used
// only after ASTAP + astrometry.net have both failed.
//
// CONTRACT (file-based IPC with the Python PixInsightSolver):
//   * Reads a params file whose path is in the env var ASTROINDEXER_PI_SOLVE_PARAMS.
//     params (key=value per line): input, output, status, ra_hint, dec_hint, fov_hint
//   * On success: saves the solved image (WCS in the FITS header) to `output` and
//     writes "SOLVED" to `status`.
//   * On any failure: writes "FAILED: <reason>" to `status` and exits. NEVER blocks
//     on a dialog (so the Python side's timeout/kill is a backstop, not the norm).
//
// ACTIVATION: this script MUST be code-signed in PixInsight (Script > Code Signing)
// before `--startup-script=` will run it headlessly; an UNSIGNED copy makes PI hang
// on a "Required code signature not found" modal (that is why PixInsightSolver gates
// is_available() on a signature and bounds the run with a hard timeout). It also
// needs a local Gaia DR3/XPSD database configured in PixInsight.
//
// Note: the #include path to the stock ImageSolver may need adjusting per install;
// PixInsight resolves includes against its script search paths.
// ============================================================================

// PixInsight 1.9.4 removed the legacy 'sm' (SpiderMonkey) engine. Declare the v8 engine
// explicitly - the stock ImageSolver.js we #include already declares '#engine v8'. Without
// this, the driver loads under the now-unavailable default engine and aborts before running.
#engine v8

// Required for code signing: PixInsight's generateScriptSignatureFile() derives the
// signed script-id from this directive (every signable stock script declares one).
#feature-id    AstroIndexerAIImageSolver : AstroIndexer > AI ImageSolver Driver

#define USE_SOLVER_LIBRARY  true
// USE_SOLVER_LIBRARY makes ImageSolver.js SKIP its own '#define SETTINGS_MODULE' (it assumes the
// embedding script owns the settings namespace), yet its catalog classes (AstronomicalCatalogs.js)
// reference SETTINGS_MODULE at load -> we MUST define it before the include. Use "ImageSolver" so the
// driver reads the user's existing ImageSolver catalog / local Gaia DR3 configuration.
#define SETTINGS_MODULE  "ImageSolver"
// Installed under <PixInsight>/src/scripts/AstroIndexer/, so ImageSolver is one level up.
// Matches the stock convention (AutoIntegrate, BatchPreprocessing both use this exact path).
#include "../ImageSolver/ImageSolver.js"

function _readParams( path )
{
   var p = { input:"", output:"", status:"", ra_hint:"", dec_hint:"", fov_hint:"" };
   var text = File.readTextFile( path );
   var lines = text.split( "\n" );
   for ( var i = 0; i < lines.length; ++i )
   {
      var s = lines[i].trim();
      var eq = s.indexOf( "=" );
      if ( eq > 0 )
         p[ s.substring( 0, eq ).trim() ] = s.substring( eq + 1 ).trim();
   }
   return p;
}

function _writeStatus( path, msg )
{
   try { File.writeTextFile( path, msg + "\n" ); } catch ( e ) {}
}

function main()
{
   var paramsPath = "";
   if ( typeof( System ) != "undefined" && typeof( System.getEnvironmentVariable ) == "function" )
      paramsPath = System.getEnvironmentVariable( "ASTROINDEXER_PI_SOLVE_PARAMS" );
   else if ( typeof( environmentVariable ) != "undefined" )
      paramsPath = environmentVariable( "ASTROINDEXER_PI_SOLVE_PARAMS" );
   if ( !paramsPath || !File.exists( paramsPath ) )
      return;  // nothing we can even report to

   var P = _readParams( paramsPath );
   if ( !P.status )
      return;

   try
   {
      if ( !P.input || !File.exists( P.input ) )
      {
         _writeStatus( P.status, "FAILED: input missing" );
         return;
      }

      // Open the target (PI reads FITS + XISF natively - no transcode needed).
      var windows = ImageWindow.open( P.input );
      if ( windows.length == 0 )
      {
         _writeStatus( P.status, "FAILED: could not open input" );
         return;
      }
      var win = windows[0];

      // Configure + run ImageSolver as a library, no dialog. API per ImageSolver 6.4.2
      // (ImageSolverEngine.js): initialize()/solveImage() - lowercase, take the WINDOW.
      var solver = new ImageSolver();
      solver.initialize( win, false /*prioritizeSettings*/ );  // load metadata from the image
      // Disable distortion correction: a non-linear (distortion-corrected) solution CANNOT be stored
      // in FITS ("Insufficient data storage capabilities"), so PI drops ALL standard WCS keywords and
      // the Python reader finds no CRVAL/CD and rejects an otherwise-perfect solve. A linear Gnomonic
      // solution writes standard FITS WCS - all AstroIndexer needs (center/scale/rotation/parity).
      solver.solverCfg.distortionCorrection = false;
      solver.metadata.width  = win.mainView.image.width;
      solver.metadata.height = win.mainView.image.height;
      // Seed hints when AstroIndexer provides them (faster, more robust solve).
      if ( P.ra_hint !== "" && P.dec_hint !== "" )
      {
         solver.metadata.ra  = parseFloat( P.ra_hint );
         solver.metadata.dec = parseFloat( P.dec_hint );
      }
      if ( P.fov_hint !== "" )
         solver.metadata.resolution = parseFloat( P.fov_hint ) / Math.max( 1, win.mainView.image.width );
      solver.metadata.SaveParameters();
      solver.solverCfg.SaveParameters();

      // solveImage() THROWS on failure (e.g. insufficient stars) - no boolean return; the
      // outer catch turns that into "FAILED: <reason>". On success it updates solver.metadata.
      solver.solveImage( win );

      // PI's FITS writer stores the astrometric solution as XISF properties (dropped on FITS save)
      // and emits NO CRVAL/CD cards, so reading the WCS back from the output FITS is unreliable.
      // Instead read the linear WCS straight from the solution and hand it to the Python side via
      // the status file - deterministic, independent of PI's FITS-keyword behaviour.
      var wcs = solver.metadata.GetWCSvalues();

      // Still save the solved image (a bonus for the user); the status WCS below is the authority.
      try {
         solver.metadata.SaveKeywords( win, false /*beginProcess*/ );
         win.saveAs( P.output, false /*queryOptions*/, false /*allowMessages*/,
                     false /*strict*/, false /*verifyOverwrite*/ );
      } catch ( e ) { /* output FITS is best-effort; Python reads the WCS from the status file */ }
      win.forceClose();

      _writeStatus( P.status,
         "SOLVED" +
         "\ncrval1=" + wcs.crval1 + "\ncrval2=" + wcs.crval2 +
         "\ncd1_1="  + wcs.cd1_1  + "\ncd1_2="  + wcs.cd1_2 +
         "\ncd2_1="  + wcs.cd2_1  + "\ncd2_2="  + wcs.cd2_2 +
         "\ncrpix1=" + wcs.crpix1 + "\ncrpix2=" + wcs.crpix2 );
   }
   catch ( e )
   {
      _writeStatus( P.status, "FAILED: " + e.toString() );
   }
}

main();
